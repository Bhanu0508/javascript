import React from "react";

function AppHeader() {
  return (
    <div className="header">
      <h1>Tic Tac Toe Game</h1>
    </div>
  );
}

export default AppHeader;
