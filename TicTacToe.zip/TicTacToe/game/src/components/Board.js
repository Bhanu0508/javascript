import React from "react";
import Cell from "./Cells";

class Board extends React.Component {
  render() {
    return (
      <div>
        <div className="board">
          {this.props.cells.map((value, index) => (
            <Cell
              id={index}
              value={value}
              onCellClick={this.props.handle}
              onWinner={this.props.win ? this.props.win.winnerArray : null}
            />
          ))}
        </div>
      </div>
    );
  }
}

export default Board;
