const MongoClient = require("mongodb").MongoClient;
// const env = require("dotenv");
// env.config();
const uri = `mongodb+srv://MernUser:MernPassword@cluster0.paayg.mongodb.net/BookManagementSystem?retryWrites=true&w=majority`;
// const uri = `mongodb+srv://${process.env.db_user}:${process.env.db_pass}@${process.env.}`
const client = new MongoClient(uri);
const dbName = "BookManagementSystem";
async function run() {
  try {
    await client.connect();
    console.log("connected to db!");
    const db = client.db(dbName);
    const row = db.collection("Books");
    // const insert = await row.insertMany([
    //   { id: "3", title: "pirates", author: "jack", rating: 8, price: 200 },
    // ]);
    // const filter = { id: "3" };
    // const option = { upsert: true };
    // const update = {
    //   $set: { author: "sparrow" },
    // };
    // const updateDoc = await row.updateOne(filter, update, option);
    const myDocs = await row.find({ author: "sparrow" });
    myDocs.forEach(element => {
      console.log(element);
    });
    // res.end(myDocs);
  } catch (err) {
    console.log(err);
  } finally {
    await client.close();
  }
}
run();
