import React from 'react';
import { connect } from 'react-redux';
import { increment, decrement } from './Redux/actions';

const Counter = (props) => {
  return (
    <div>
      <h1>Counter: {props.count}</h1>
      <button onClick={props.increment}>Increment</button>
      <button onClick={props.decrement}>Decrement</button>
    </div>
  );
};

// mapStateToProps: Maps the Redux state to component props
const mapStateToProps = (state) => {
  return {
    count: state.count,
  };
};

// mapDispatchToProps: Maps the dispatching of actions to props
const mapDispatchToProps = (dispatch) => {
  return {
    increment: () => dispatch(increment()),
    decrement: () => dispatch(decrement()),
  };
};

// Connect the component to Redux
export default connect(mapStateToProps, mapDispatchToProps)(Counter);
