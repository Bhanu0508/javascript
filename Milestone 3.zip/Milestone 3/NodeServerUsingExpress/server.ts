// const express = require('express')
import express from 'express'
// const mongoose = require('mongoose')
import mongoose from 'mongoose'
import {router} from "./bookHandler"
import env from 'dotenv'
env.config();
// const url  = `mongodb+srv://${process.env.db_user}:${process.env.db_pass}@${process.env.db_server}/BookManagement?retryWrites=true&w=majority`;
const url = `mongodb+srv://${process.env.db_user}:${process.env.db_password}@cluster0.paayg.mongodb.net/${process.env.db_name}?retryWrites=true&w=majority`;
const app = express()

mongoose.connect(url, {useNewUrlParser:true})
const con = mongoose.connection

con.on('open', () => {
    console.log('connected...')
})


app.use(express.json())

const bookRouter = require('./bookHandler')
app.use('/books',router)

app.listen(8000, () => {
    console.log('Server started')
})