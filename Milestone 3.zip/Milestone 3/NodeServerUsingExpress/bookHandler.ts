// const express = require('express')
import express from 'express'
import book from './bookModel'
export const router = express.Router()
// const book = require('./bookModel')



router.get('/', async(req:any,res:any) => {
    try{
           const books = await book.find()
           res.json(books)
    }catch(err){
        res.send('Error ' + err)
    }
})

router.get('/:id', async(req:any,res:any) => {
    try{
           const books = await book.findById(req.params.id)
           res.json(books)
    }catch(err){
        res.send('Error ' + err)
    }
})


router.post('/', async(req:any,res:any) => {
    const books = new book({
        // console.log("hii");
        title: req.body.title,
        author: req.body.author,
        rating: req.body.rating,
        price: req.body.price
    })

    try{
        // console.log("hii");
        const a1 =  await books.save()
        // console.log("hello");
        res.json(a1)
    }catch(err){
        res.send('Error')
    }
})

router.patch('/:id',async(req:any,res:any)=> {
    try{
        const books:any|null = await book.findById(req.params.id)
        if(req.body.title)
        books.title = req.body.title
        if(req.body.author)
        {
            console.log("hii");
            books.author=req.body.author
        }
        if(req.body.rating)
        books.rating=req.body.rating
        if(req.body.price)
        books.price=req.body.price
        const a1 = await books.save()
        res.json(a1)   
    }catch(err){
        res.send('Error')
    }

})

router.delete('/:id',async(req:any,res:any)=> {
    try{
        const books:any|null = await book.findById(req.params.id) 
        // books.sub = req.body.sub
        const a1 = await books.remove()
        res.json(a1)   
    }catch(err){
        res.send('Error')
    }

})


// module.exports = router
