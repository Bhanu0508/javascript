import React, { Component } from 'react';
import { bindActionCreators } from 'redux';
import * as ActionExports from "./actions"
// Redux Imports
import { connect } from 'react-redux';
// import { submitValue } from '../Redux/actions/submittedValueActions';


const mapStateToProps = (state) => {
    return {
        searchText: state.reducer.searchText
    };
};

const mapDispatchToProps = (dispatch) => ({
    actions: bindActionCreators(ActionExports, dispatch)
})


class Input extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }



    render() {
        const { searchText, actions } = this.props
        console.log({ searchText, actions })
        return (
            <div>
                <h1>Output : {searchText}</h1>
            </div>
        );
    }
}




export default connect(mapStateToProps, mapDispatchToProps)(Input);