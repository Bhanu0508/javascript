import * as types from "./constants";


export const setSearchText = data => ({
  type: types.SET_SEARCH_TEXT,
  payload: data
});