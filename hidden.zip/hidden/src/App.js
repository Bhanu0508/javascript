import './App.css';
import Input from "./input"
import Output from "./output"

function App() {
  return (
    <div className="App">
      <Input />
      <Output />
    </div>
  );
}

export default App;
