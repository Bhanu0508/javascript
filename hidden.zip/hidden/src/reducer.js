import * as types from "./constants";
import update from "immutability-helper"

export const initialState = {
    searchText: "_______"    
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case types.SET_SEARCH_TEXT:
            return update(state, { searchText: { $set: action.payload.searchText } });
        default:
            return state;
    }
};

export default reducer;

