import React, { Component } from 'react';
import { bindActionCreators } from 'redux';
import * as ActionExports from "./actions"
// Redux Imports
import { connect } from 'react-redux';
// import { submitValue } from '../Redux/actions/submittedValueActions';


const mapStateToProps = (state) => {
	return {
		searchText: state.reducer.searchText
	};
};

const mapDispatchToProps = (dispatch) => ({
	actions: bindActionCreators(ActionExports, dispatch)
})


class Input extends Component {
	constructor(props) {
		super(props);
		this.state = {
			inputValue: "",
		};

		this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleReset = this.handleReset.bind(this);
	}

	handleChange(event) {
		this.setState({ inputValue: event.target.value });
	}

	handleSubmit(event) {
		this.props.actions.setSearchText({ searchText: this.state.inputValue });
		event.preventDefault();
	}

	handleReset(event) {
		this.setState({ inputValue: '' });
		event.preventDefault();
	}


	render() {
		const {searchText,actions}=this.props
		console.log({searchText,actions})
		return (
			<div>
				<form onSubmit={this.handleSubmit} onReset={this.handleReset}>
					<label>
						Input: <input type="text" value={this.state.inputValue} onChange={this.handleChange} />
					</label>
					<input type="submit" value="Submit" />
					<input type="reset" value="Clear" /> 
				</form>
			</div>
		);
	}
}




export default connect(mapStateToProps, mapDispatchToProps)(Input);