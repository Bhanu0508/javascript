// const Players = [
//   "Bhanu",
//   "K L Rahul",
//   "M S Dhoni",
//   "Virat Kohli",
//   "Suresh Raina",
// ];
// const result = Players.filter(player => player.length > 10);
// console.log(result);

// const Players = [
//   "Bhanu",
//   "K L Rahul",
//   "M S Dhoni",
//   "Virat Kohli",
//   "Suresh Raina",
// ];

// var filterFun = () => {
//   let Team = [];
//   for (const player of Players) {
//     if (player.length > 10) {
//       Team.push(player);
//     }
//   }
//   return Team;
// };
// let result = filterFun();
// console.log(result);

Array.prototype.mYFilter = function (filterFun) {
  const filterArray = [];
  for (let i = 0; i < this.length; i++) {
    const result = filterFun(this[i], i, this);
    if (result) {
      filterArray.push(this[i]);
    }
  }
  return filterArray;
};
const Arr = [2, 4, 5, 7, 8, 10];
let result = Arr.mYFilter(e => e % 2 === 0);
console.log(result);
