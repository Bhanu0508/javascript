// const Numbers = [2, 4, 6, 8];
// const result = Numbers.map(number => number / 2);
// console.log(result);

// const Numbers = [2, 4, 6, 8];

// var mapFun = () => {
//   let result = [];
//   for (const number of Numbers) {
//     result.push(number % 2);
//   }
//   return result;
// };
// let result = mapFun();
// console.log(result);

Array.prototype.myMap = function (mapFun) {
  const mapArray = [];
  for (let i = 0; i < this.length; i++) {
    const result = mapFun(this[i], i, this);
    mapArray.push(result);
  }
  return mapArray;
};
const Arr = [2, 4, 5, 7, 8, 10];
let result = Arr.myMap(e => e * 2);
console.log(result);
