import bodyParser from "body-parser";
import express from "express";
import { error } from "node:console";
import { ppid, title } from "node:process";
const port =3000;
const app=express();
const mongoose= require('mongoose');
const Book= require('./book');
//let bodyPar= require('body-parser');
// const dbURI=`mongodb+srv://user_1:Jeni@998@cluster0.r2jbq.mongodb.net/test1?retryWrites=true&w=majority`;
const dbURI = `mongodb+srv://MernUser:MernPassword@cluster0.paayg.mongodb.net/BookManagementSystem?retryWrites=true&w=majority`;
mongoose.connect(dbURI,{useNewUrlParser:true,useUnifiedTopology:true})
    .then((_result: any) => {
        app.listen(port, () => {
            console.log(`Server Started at port ${port}`);
            console.log("connected successfully to Data Base");
            
        });
    })
.catch((err: any)=>console.log(err));
app.use(bodyParser.json());
app.get("/books",(_req,res)=>{
Book.find()
    .then((result: any)=>{
        res.send(result);
    })
    .catch((error: Error)=>console.log(error))
})
app.get("/books/:id",(req,res)=>{
    const id= req.params.id;
    //Book.findById('60768abb5d8c4f437c22a18b')
    Book.findById(id)
    .then((result: any)=>{
        res.send(result);
    })
    .catch((error: Error)=>console.log(error))
})
app.delete("/books/:id",(req,res)=>{
   const id= req.params.id;
//    Book.remove({_id:id})
//    .then(()=>{
//        res.status(200).json({
//            message:`Book with ${id} deleted`
//        })
//    })
//    .catch((err:Error)=>console.log(err));
Book.deleteOne({_id:id})
.then(()=>{
    res.status(200).json({
        message:'Books deleted'
    })
})
.catch((error:Error)=>console.log(error))
})
app.post('/books',(req,res)=>{
    let book=new Book(req.body);
    book.save();
    res.send(book);
});
app.put('/books/:id',(req,res)=>{
    const book=new Book({
        _id:req.params.id,
        title:req.body.title,
        author:req.body.author,
        price:req.body.price,
        rating:req.body.rating,
    });
    Book.update({_id:req.params.id},book)
    .then(()=>{
        res.status(201).json({
            message:'Book updated successfully'
        })
    }).catch((error:Error)=>console.log(error))

})

