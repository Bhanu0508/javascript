function divide(x, y) {
  let promise = new Promise(function (resolve, reject) {
    setTimeout(() => {
      if (y == 0) return reject("division by 0");
      //error meassage
      else return resolve(x / y); //correct answer
    }, 2000);
  });
  return promise;
}
function testDivide(a, b) {
  let promise = divide(a, b);
  promise
    .then(result => console.log(`divide (${a} , ${b})=>${result}`))
    .catch(result => console.log(`error divide(${a},${b})=>${result}`));
  console.log("trying to divide", a, "/", b);
}
testDivide(2, 3);
testDivide(10, 0);
