function divide(a, b) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      let prime = [];
      for (let i = a; i <= b; i++) {
        if (i == 1) {
          notPrime = true;
        } else {
          let notPrime = false;
          for (let j = 2; j <= i / 2; j++) {
            if (i % j === 0 && j != i) {
              notPrime = true;
            }
          }
          if (notPrime === false) {
            prime.push(i);
          }
        }
      }
      if (prime.length == 0) return reject("no primes found");
      //error meassage
      else return resolve(prime); //correct answer
    }, 2000);
  });
}
function testDivide(a, b) {
  let promise = divide(a, b);
  promise
    .then(result => console.log(result))
    .catch(result => console.log(`error : ${result} between ${a} and ${b}`));
  console.log("trying to get primes between", a, " and ", b);
}

const callMe = async () => {
  await testDivide(2, 10);
  testDivide(2, 100);
};
callMe();
