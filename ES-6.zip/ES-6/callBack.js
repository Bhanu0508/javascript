// function plus(x, y) {
//   setTimeout((x, y) => {
//     return x + y;
//   }, 2000);
// }
// let result = plus(2, 3);
// console.log("result :", result);

function plus(x, y, cb) {
  setTimeout(() => {
    cb(x + y);
  }, 2000);
}

function printResult(result) {
  console.log(result);
}
plus(20, 45, printResult);
// plus(10, 30, result => console.log(result));
// plus(30, 50, console.log);
console.log("let's wait for interval...");
