function findPrimes(x, y, cb, interval) {
  setTimeout(() => {
    cb(x, y);
  }, interval);
}

function printResult(a, b) {
  let prime = [];
  for (let i = a; i <= b; i++) {
    let notPrime = false;
    if (i == 1) {
      notPrime = true;
    } else {
      for (let j = 2; j <= i / 2; j++) {
        if (i % j === 0 && j != i) {
          notPrime = true;
        }
      }
      if (notPrime === false) {
        prime.push(i);
      }
    }
  }
  console.log(prime);
}

findPrimes(2, 100, printResult, 5000);
findPrimes(2, 50, printResult, 4000);
findPrimes(2, 10, printResult, 2000);

// plus(10, 30, result => console.log(result));
// plus(30, 50, console.log);
console.log("let's wait for interval...");
