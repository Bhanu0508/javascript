const one = () => {
  return "this is first function";
};
const two = () => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve("this is second function");
      //   reject("error");
    }, 2000);
  });
};
const three = () => {
  return "this is third function";
};

const callMe = async () => {
  let first = one();
  console.log(first);

  let second = await two();
  console.log(second);

  let third = three();
  console.log(third);
};
callMe();
