export class Book {
    constructor(id, title, author, rating, price, coverPhotoUrl) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.rating = rating;
        this.price = price;
        this.coverPhotoUrl = coverPhotoUrl;
    }
}
;
